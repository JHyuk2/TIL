price = int(input("가격을 입력하세요: "))
count = int(input("개수를 입력하세요: "))
print(f"총액은 {price * count} 원입니다.")
