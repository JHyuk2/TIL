i, k = 0, 0

for i in range(2, 10, 1):
    for k in range(1, 10, 1):
        print(f'{i} * {k} = {i * k}')