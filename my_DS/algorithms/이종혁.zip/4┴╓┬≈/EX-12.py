a = 75

if a>50:
    if a<100:
        print("50~100 사이의 값입니다.")
    else:
        print('100보다 큰 수입니다.')
else:
    print('50보다 작은 수입니다.')