print('%d' %123)
print('%5d' %123)
print('%05d' %123)

print('%f' %123.45)
print('%7.1f' %123.45)
print('%7.3f' %123.45)

print('%s' %"SKKU")
print('%10s' %"SKKU")