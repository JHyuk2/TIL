i, hap = 0, 0

for i in range(501, 1001, 2):
    hap += i

print('500에서 1000까지 홀수의 합 : %d' %hap)