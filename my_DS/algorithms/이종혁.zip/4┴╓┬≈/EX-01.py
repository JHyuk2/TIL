a = int(input('첫 번째 숫자: '))
b = int(input('두 번째 숫자: '))

result = a+b
print(f'{a} + {b} = {result}')
result = a-b
print(f'{a} - {b} = {result}')
result = a*b
print(f'{a} * {b} = {result}')
result = a/b
print(f'{a} / {b} = {result}')